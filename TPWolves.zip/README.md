
# Teleport Tamed Wolves in Valheim

With this little BepInEx plugin you can easily take your pet wolves to adventures all around the world. Now nothing can stop you and your army of good boys.

To teleport a wolf set it to follow you and step through a portal. 

## Configuration

You can configurate the maximum number of wolves that can teleport simultaneously and how far away they can be from the player to be teleported. The default number of wolves is 4 as a big crowd tends to barricade the targeted portal. The default distance is 20 units.

## Multiplayer

It is not mandatory for the server to have the plugin installed. Every player who has it can teleport his tamed pets.

## Installation

To install the mod you need to extract the contents of "plugins" folder into "<GameDirectory>\Bepinex\plugins".
The configuration file "Toawy.TPWolves.cfg" is generated after you start the game once.


